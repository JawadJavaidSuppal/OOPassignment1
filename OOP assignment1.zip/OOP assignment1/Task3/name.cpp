#include "Name.h"


void Name::setvaluefirst(char* n)
{
	int count = strlen(n);
	count = count + 1;
	firstName = new char(count);
	for (int a = 0; a <= count; a++)
	{
		firstName[a] = n[a];
	}
}
void Name::setvaluelast(char* m)
{
	int count = strlen(m);
	count = count + 1;
	lastName = new char(count);
	for (int a = 0; a <= count; a++)
	{
		lastName[a] = m[a];
	}
}

void Name::copyName(Name& n1) //this is not a copy constructor, I want this function to copy the contents of one name(firstName and lastName both) to another name.
{
	int count = 0;
	for (int a = 0; a < n1.firstName[a] != '\0'; a++)
	{
		n1.firstName[a];
		count++;
	}
	firstName = new char[count];
	for (int a = 0; a <= count; a++)
	{
		firstName[a] = n1.firstName[a];
	}
	count = 0;
	for (int a = 0; a < n1.lastName[a] != '\0'; a++)
	{
		n1.lastName[a];
		count++;
	}
	lastName = new char[count];
	for (int a = 0; a < count; a++)
	{
		lastName[a] = n1.lastName[a];
	}

}

Name::~Name()//destructor
{

}

bool Name::isValidName()// name should contain only alphabets - no special characters or digits
{

	int count = 0, count1 = 0;
	for (int a = 0; a < firstName[a] != '\0'; a++)
	{
		firstName[a];
		count++;
	}
	for (int a = 0; a < lastName[a] != '\0'; a++)
	{
		lastName[a];
		count1++;
	}
	int result = count + count1;
	char* FULLNAME = new char[result];
	int c1 = 0;
	for (int a = 0; a < count; a++)
	{
		FULLNAME[a] = firstName[a];
		c1++;
	}
	for (int a = 0; a <= count1; a++)
	{
		FULLNAME[c1] = lastName[a];
		c1++;
	}
	char cheak; int cheaker = 0;
	for (int a = 0; FULLNAME[a] != '\0'; a++)
	{
		cheak = FULLNAME[a];
		if (cheak >= 65 && cheak <= 95 || cheak >= 97 && cheak <= 122)
		{
			cheaker = cheaker + 1;
		}
		else
		{
			cheaker = cheaker - 1;
		}
	}
	if (cheaker == result)
	{
		return true;
	}
	else {

		return false;
	}
}

char* Name::fullName() //concatenate both attributes and return full name with a space in between both
{
	int count = 0, count1 = 0;
	for (int a = 0; a < firstName[a] != '\0'; a++)
	{
		firstName[a];
		count++;
	}
	for (int a = 0; a < lastName[a] != '\0'; a++)
	{
		lastName[a];
		count1++;
	}
	int result = count + count1;
	result = result + 1;
	char* FULLNAME = new char[result];
	int c1 = 0;
	for (int a = 0; a < count; a++)
	{
		FULLNAME[a] = firstName[a];
		c1++;
	}
	FULLNAME[c1] = ' ';
	c1 = c1 + 1;
	for (int a = 0; a <= count1; a++)
	{
		FULLNAME[c1] = lastName[a];
		c1++;
	}

	return FULLNAME;
}
Name::Name(const Name& obj)
{
	int size = strlen(obj.firstName);
	size = size + 1;
	firstName = new char[size];
	for (int a = 0; a <= size; a++)
	{
		firstName[a] = obj.firstName[a];
	}
	int size1 = strlen(obj.lastName);
	size1 = size1 + 1;
	lastName = new char[size1];
	for (int a = 0; a <= size1; a++)
	{
		lastName[a] = obj.lastName[a];
	}
}

void Name::display() //prints name(firstName and lastName with space in between)
{
	cout << firstName << " " << lastName << endl;
}
void Name::swapNames() // firstName becomes lastName and vice versa
{
	int count = 0, count1 = 0;
	for (int a = 0; a < firstName[a] != '\0'; a++)
	{
		firstName[a];
		count++;
	}
	for (int a = 0; a < lastName[a] != '\0'; a++)
	{
		lastName[a];
		count1++;
	}
	char* name1 = new char[count];
	char* name2 = new char[count1];
	for (int a = 0; a <= count; a++)
	{
		name1[a] = firstName[a];
	}
	for (int a = 0; a <= count1; a++)
	{
		name2[a] = lastName[a];
	}
	firstName = new char[count1];
	for (int a = 0; a <= count1; a++)
	{
		firstName[a] = name2[a];
	}
	lastName = new char[count];
	for (int a = 0; a <= count; a++)
	{
		lastName[a] = name1[a];
	}

}

int Name::nameLength() // both first and last (excluding space)
{
	int count = 0, count1 = 0;
	for (int a = 0; a < firstName[a] != '\0'; a++)
	{
		firstName[a];
		count++;
	}
	for (int a = 0; a < lastName[a] != '\0'; a++)
	{
		lastName[a];
		count1++;
	}
	int result = count + count1;
	return result;
}
int Name::nameLengthfirst() // both first and last (excluding space)
{
	int count = 0;
	for (int a = 0; a < firstName[a] != '\0'; a++)
	{
		firstName[a];
		count++;
	}
	return  count;
}
int Name::nameLengthlast() // both first and last (excluding space)
{
	int count1 = 0;
	for (int a = 0; a < lastName[a] != '\0'; a++)
	{
		lastName[a];
		count1++;
	}
	return count1;
}




void Name::toUpper() //convert name into upper case alphabets
{
	int size = 0, count = 0; char test;
	for (int a = 0; firstName[a] != '\0'; a++)
	{
		test = firstName[a];
		count++;

	}
	size = count;
	char change, waste;
	char* temp = new char[size];
	for (int a = 0; a <= size; a++)
	{
		temp[a] = firstName[a];
	}
	for (int a = 0; a < size; a++)
	{
		change = temp[a];
		if (change >= 97 && change <= 122)
		{
			change = change - 32;
			temp[a] = change;
		}
		else {
			waste = change;
		}
	}
	for (int a = 0; a < size; a++)
	{
		firstName[a] = temp[a];
	}
	// for lastname
	size = 0; count = 0;
	char change1, waste1;
	for (int a = 0; lastName[a] != '\0'; a++)
	{
		test = lastName[a];
		count++;
		size = count;
	}
	temp = new char[size];
	for (int a = 0; a <= size; a++)
	{
		temp[a] = lastName[a];
	}
	for (int a = 0; a < size; a++)
	{
		change1 = temp[a];
		if (change1 >= 97 && change1 <= 122)
		{
			change1 = change1 - 32;
			temp[a] = change1;
		}
		else {
			waste1 = change1;
		}
	}
	for (int a = 0; a < size; a++)
	{
		lastName[a] = temp[a];
	}



}
Name::Name(char* first, char* last) // constructor parameterized assining
{
	int size = 0, count = 0; char test;
	for (int a = 0; first[a] != '\0'; a++)
	{
		test = first[a];
		count++;
		size = count;
	}
	firstName = new char[size];
	for (int a = 0; a <= size; a++)
	{
		firstName[a] = first[a];
	}
	// for second name
	size = 0; count = 0;
	for (int a = 0; last[a] != '\0'; a++)
	{
		test = last[a];
		count++;
		size = count;
	}
	lastName = new char[size];
	for (int a = 0; a <= size; a++)
	{
		lastName[a] = last[a];
	}
}
void Name::toLower() //convert name to lower case alphabets
{
	int size = 0, count = 0; char test;
	for (int a = 0; firstName[a] != '\0'; a++)
	{
		test = firstName[a];
		count++;

	}
	size = count;
	char change, waste;
	char* temp = new char[size];
	for (int a = 0; a <= size; a++)
	{
		temp[a] = firstName[a];
	}
	for (int a = 0; a < size; a++)
	{
		change = temp[a];
		if (change >= 65 && change <= 95)
		{
			change = change + 32;
			temp[a] = change;
		}
		else {
			waste = change;
		}
	}
	for (int a = 0; a < size; a++)
	{
		firstName[a] = temp[a];
	}
	// for lastname
	size = 0; count = 0;
	char change1, waste1;
	for (int a = 0; lastName[a] != '\0'; a++)
	{
		test = lastName[a];
		count++;
		size = count;
	}
	temp = new char[size];
	for (int a = 0; a <= size; a++)
	{
		temp[a] = lastName[a];
	}
	for (int a = 0; a < size; a++)
	{
		change1 = temp[a];
		if (change1 >= 65 && change1 <= 95)
		{
			change1 = change1 + 32;
			temp[a] = change1;
		}
		else {
			waste1 = change1;
		}
	}
	for (int a = 0; a < size; a++)
	{
		lastName[a] = temp[a];
	}
}


char* Name::getvaluelast() // get value for last attribute
{
	int size = 0, count = 0; char test;
	for (int a = 0; lastName[a] != '\0'; a++)
	{
		test = lastName[a];
		count++;
	}
	size = count;
	char* temp = new char[size];
	for (int a = 0; a <= size; a++)
	{
		temp[a] = lastName[a];
	}
	return temp;
}
char* Name::getvaluefirst()  // get value for first attribute
{
	int size = 0, count = 0; char test;
	for (int a = 0; firstName[a] != '\0'; a++)
	{
		test = firstName[a];
		count++;
	}
	size = count;
	char* temp = new char[size];
	for (int a = 0; a <= size; a++)
	{
		temp[a] = firstName[a];
	}
	return temp;
}

void Name::camelCase()   // First letter of each attribute is large
{
	char tempo;
	tempo = firstName[0];
	if (tempo >= 97 && tempo <= 122)
	{
		tempo = tempo - 32;
	}
	else {
		cout << "FIRST WORD IS ALREADY CAPITAL" << endl;
	}
	firstName[0] = tempo;

	char tempo1;
	tempo1 = lastName[0];
	if (tempo1 >= 97 && tempo1 <= 122)
	{
		tempo1 = tempo1 - 32;
	}
	else {
		cout << "FIRST LETTER IS ALREADY CAPITAL" << endl;
	}
	lastName[0] = tempo1;
}

