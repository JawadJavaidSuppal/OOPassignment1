#include "Name.h"

int nameCompare(Name name1, Name name2);
int main()
{
	Name name1("Ali", "has");
	Name name2("ALI", "Has");
	int n = 9;
	n = nameCompare(name1, name2);
	if (n != 9)
	{

		if (n == 0)
		{
			cout << "NAME IS IDENTICAL" << endl;
		}
		else if (n > 0)
		{
			cout << "Name1 have the greater ASCII value than the corresponding character in Name2" << endl;

		}
		else if (n < 0)
		{
			cout << "Name2 have the greater ASCII value than the corresponding character in Name1 " << endl;

		}

	}
	else {};
	return 0;
}
int nameCompare(Name name1, Name name2)
{
	int siz = name1.nameLengthfirst();
	int siz1 = name2.nameLengthfirst();
	int size = name1.nameLengthlast();
	int size2 = name2.nameLengthlast();
	char* pro = name1.getvaluefirst();
	char* pro1 = name1.getvaluelast();
	char* proo = name2.getvaluefirst();
	char* pro2 = name2.getvaluelast();
	int cheak = 0;
	int cheaker = 0;
	if (siz == siz1 && size == size2)
	{
		for (int a = 0; a < size; a++)
		{
			if (pro1[a] == pro2[a])
			{
				cheak = cheak + 1;
			}
			else {
				cout << "LAST NAME IS NOT EQUAL" << endl;
				int res = pro1[a] - pro2[a];
				cout << "DIFFERENCE OF ASSCI IS  = " << res << endl;
				break;
			}
		}
		if (cheak > 0)
		{
			for (int a = 0; a < siz; a++)
			{
				if (pro[a] == proo[a])
				{
					cheaker = cheaker + 1;
				}
				else if (pro[a] > proo[a])
				{
					return 1;

				}
				else if (pro[a] < proo[a])
				{
					return -1;

				}
				else {
					int res1;
					res1 = pro[a] - proo[a];
					cout << "DIFFERENCE OF ASSCI IS  = " << res1 << endl;
				};
			}
			if (cheaker == siz)
			{
				return 0;
			}
		}
		else {
			cout << "LAST NAME NOT MATCHED ";
			return 9;

		}
	}
	else {
		cout << "NAME LENGTH IS NOT EQUAL" << endl;
		return 9;
	}
}