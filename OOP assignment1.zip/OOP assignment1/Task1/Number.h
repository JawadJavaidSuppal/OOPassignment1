#include<iostream>
using namespace std;

class  MyNum {
private:
	int num;

public:
	MyNum(int);
	MyNum();
	~MyNum();
	void setvalue(int);
	int getvalue();
	void pos();
	void Neg();
};
