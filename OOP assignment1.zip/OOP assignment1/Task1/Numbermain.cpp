#include "Number.h"

int main()
{
	int valdata;
	int	objno;
	cout << "Enter the data of integer = ";
	cin >> valdata;
	MyNum n1(valdata);
	cout << "Your entered data is =  " << n1.getvalue() << endl;
	cout << "Enter how many objects you want to make = ";
	cin >> objno;
	MyNum* arr1 = new MyNum(objno);
	int* arr = new int(objno); 
	int b = 1;
	for (int a = 0; a < objno; a++)
	{
		arr[a] = b;
		b++;
	}
	int in;
	for (int a = 0; a < objno; a++)
	{
		cout << "Enter integer data at object " << arr[a] << " = ";
		cin >> in;
		arr1[a].setvalue(in);
	}
	cout << "BEFORE SORTING " << endl;

	for (int a = 0; a < objno; a++)
	{
		cout << "AT OBJECT " << arr[a] << " value is = " << arr1[a].getvalue() << endl;
	}
	cout << "AFTER SORTING " << endl;
	int tempo = 0; 
	int temp; 
	int go;
	for (int a = 1; a < objno; a++)
	{
		for (int b = 0; b <= objno - 1; b++) {
			if (arr1[b].getvalue() > arr1[a].getvalue())
			{
				tempo = arr1[b].getvalue();
				go = arr1[a].getvalue();
				arr1[b].setvalue(go);
				arr1[a].setvalue(tempo);

				temp = arr[b];
				arr[b] = arr[a];
				arr[a] = temp;
			}
		}
	}
	for (int a = 0; a < objno; a++)
	{
		cout << "AT OBJECT " << arr[a] << " value is = " << arr1[a].getvalue() << endl;
	}

	return 0;
}