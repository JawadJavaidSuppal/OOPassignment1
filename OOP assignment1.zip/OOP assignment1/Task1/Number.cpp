#include "Number.h"

MyNum::MyNum(int n){
	num = n;
}

MyNum::~MyNum(){

}

MyNum::MyNum(){
}

void MyNum::setvalue(int p)
{
	num = p;
}

int MyNum::getvalue()
{
	return num;
}
void MyNum::pos()
{
	if (num < 0)
	{
		num = -(num);
	}
	else {
		cout << " The value is already postive " << endl;
	}
}
void MyNum::Neg()
{
	if (num > 0)
	{
		num = -(num);
	}
	else {
		cout << " The value is already Negitive " << endl;
	}
}