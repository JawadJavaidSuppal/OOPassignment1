#include "MyChar.h"

MyChar::MyChar(){
}

MyChar::~MyChar(){
}

MyChar::MyChar(char p){
	var = p;
}

void MyChar::setvar(char n){
	var = n;
}

char MyChar::getvar(){
	return var;
}

void MyChar::lower(){
	var = var + 32;

}

void MyChar::upper(){
	var = var - 32;

}