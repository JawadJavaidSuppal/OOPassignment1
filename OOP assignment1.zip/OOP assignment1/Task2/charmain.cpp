#include "MyChar.h"

int main()
{
	char chr;
	cout << "Enter  charater = ";
	cin >> chr;
	MyChar c1(chr);
	cout << "You Entered = " << c1.getvar() << endl;
	cout << "Enter the number of objects = ";
	int val;
	cin >> val;
	char Noo = 'A';
	MyChar* arr = new MyChar(val);
	char* arr1 = new char(val);
	for (int a = 0; a < val; a++)
	{
		arr1[a] = Noo;
		Noo++;
	}
	char nii;
	for (int a = 0; a < val; a++)
	{
		cout << " ENTER CHAR at OBJECT " << arr1[a] << " = ";
		cin >> nii;
		arr[a].setvar(nii);
	}
	char go, g1, g2;
	for (int a = 0; a < val; a++)
	{
		cout << " CHARS AT OBJECT " << arr1[a] << " is = " << arr[a].getvar() << endl;
	}
	for (int a = 1; a < val; a++)
	{
		for (int b = 0; b < val - 1; b++)
		{
			if (arr[b].getvar() > arr[a].getvar())
			{
				go = arr[b].getvar();
				g2 = arr[a].getvar();
				arr[b].setvar(g2);
				arr[a].setvar(go);

				g1 = arr1[b];
				arr1[b] = arr1[a];
				arr1[a] = g1;

			}
		}
	}
	cout << "CHRACTERS AFTER SORTING (BY ASSCI CAPITAL LETTERS HAVE HIGH PRIORITY) = " << endl;
	for (int a = 0; a < val; a++)
	{
		cout << "CHARS AT OBJECT " << arr1[a] << " is = " << arr[a].getvar() << endl;
	}

	return 0;

}