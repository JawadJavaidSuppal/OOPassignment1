#include<iostream>
using namespace std;
class MyChar{
private:
	char var;

public:
	MyChar();
	~MyChar();
	MyChar(char);
	void setvar(char);
	char getvar();
	void upper();
	void lower();
};